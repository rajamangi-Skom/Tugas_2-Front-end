function ListNamaDoctor({ name, spesialis }) {
  return (
    <div>
      <ul>
        <li>Nama : {name} </li>
        <span>Spesialis : {spesialis}</span>
      </ul>
    </div>
  );
}

export default ListNamaDoctor;
