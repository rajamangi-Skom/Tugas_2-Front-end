function Header() {
  return (
    <div>
      <h1> 🩺 Layanan Kesehatan Online</h1>
      <hr />
      <ul>
        <li>Home</li>
        <li>Tentang Kami</li>
        <li>Dashboard</li>
        <li>Login</li>
      </ul>
      <hr />
    </div>
  );
}

export default Header;
